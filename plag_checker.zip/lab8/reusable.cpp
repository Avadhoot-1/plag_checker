#include <vector>
using namespace std;
#include <string>
#include <cassert>

class word {

private:
    string s;
    int freq;
    vector <unsigned int > positions;

public:

    word (string s1 , vector < string > v){
        int n = 0;
        for(unsigned int i = 0 ; i < v.size(); i ++){
            assert (i >= 0 && i < v.size());
            if(v.at(i) == s1){
                n++;
                positions.push_back(i);
            }
        }

        freq = n;
        s = s1;
        assert(freq > 0);
    }

    bool is_identical(word w2){
        if(s == w2.s && freq == w2.freq){
            return true;
        } 
        else if( freq ==  w2.freq){

            if(freq > 2){
                int matches = 0;
                for(unsigned int i = 0; i < freq ; i++){
                    if(positions.at(i) == (w2.positions).at(i)){
                        matches ++;
                    }
                }

                if (matches >= freq - 1){
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        else 
            return false;
    }

    bool is_exact_same( word w2){
        if(s == w2.s ){
            return true;
        }
        
        else 
            return false;
    }

};

void setup (ifstream &file1 , ifstream &file2 , vector < word > &w1 , vector < word > &w2) {
    string words;
    vector < string > f1 , f2;
    while(file1 >> words){
        f1.push_back(words);
    }

    while(file2 >> words){
        f2.push_back(words);
    }

    assert(f1.size() > 20 && f2.size() > 20);                            // assertion:: too short codes cannot be used!!

    for(unsigned int i = 0 ; i < f1.size(); i++){
        word w(f1.at(i), f1);
        w1.push_back(w);
    }

    for(unsigned int i = 0 ; i < f2.size(); i++){
        word w(f2.at(i), f2);
        w2.push_back(w);
    }
}


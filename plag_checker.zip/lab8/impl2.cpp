#include <fstream>
#include <string>
#include <cmath>
#include <cassert>
#include "reusable.cpp"
using namespace std;
#include "similarity.h"

// definition of the same function, but another variant

// exactly the same name! which you cannot specify in the same file!


int checksimilarity (string n1, string n2) {

    ifstream file1(n1), file2(n2); 
    vector < word > w1 , w2;

    setup(file1 , file2 , w1 ,  w2);              // from reusable.cpp
    double plag_cases = 0;

    for(unsigned int i = 0; i < w1.size(); i++){
        assert(i >=0 && i < w1.size());

        for(unsigned int j = 0; j < w2.size() ; j++){
            assert(j >= 0 && j < w2.size());

            if(w1.at(i).is_identical(w2.at(j))){
                plag_cases ++;
                break;
            }
        }
    }

    double max_plag = max(w1.size() , w2.size());
    assert(max_plag >= plag_cases);
    int score = 100.0 * plag_cases / max_plag;
    assert(score >= 0 && score <= 100);
    return score; 

}


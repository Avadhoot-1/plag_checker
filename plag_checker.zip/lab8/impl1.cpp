#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <cassert>
#include "reusable.cpp"
using namespace std;
#include "similarity.h"


// definition of the function: one variant


int checksimilarity (string n1, string n2) {

    ifstream file1(n1), file2(n2); 
    vector < word > w1 , w2;                                                 // from reusable.cpp

    setup(file1 , file2 , w1 ,  w2);                                      // from reusable.cpp

    double plag_cases = 0 ;

    for (unsigned int i = 0; i < w1.size() ; i++){

        assert( i >=0 && i < w1.size());                                   // assertion

        for(unsigned int j = 0; j < w2.size(); j++){

            assert(j >=0 && j < w2.size());                                 // assertion

            if(w1.at(i).is_exact_same(w2.at(j))){
                int similar = 0 ;
                int total = 0;
                for(int k = 0 ; k < 6 ; k++){
                    if(i + k < w1.size()  && j + k < w2.size()){                      
                        total ++;
                        if(w1.at(i+k).is_exact_same(w2.at(j+k)))
                            similar ++;
                               
                    }
                }

                if(similar >= total - 1){
                    plag_cases ++;
                    break;
                }

                if(similar == total - 2){
                    plag_cases += 0.5;
                    break;
                }
            }

        }
    }


    double max_plag = max(w1.size() , w2.size());
    assert (max_plag >= plag_cases);                                         // assertion
    int score  = 100.0 * plag_cases / max_plag ;
    assert (score >= 0 && score <= 100);                                     // assertion
    return score;

}

